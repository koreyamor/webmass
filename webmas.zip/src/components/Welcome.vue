<template>
    <div>
        <h3>welcome</h3>
        </div>
</template>

<script>
export default {
    name:'WelcomeComponent'
}
</script>