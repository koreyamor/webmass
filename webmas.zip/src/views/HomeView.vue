<template>
  <div></div>
</template>

<script>
// import CommonAside from '../components/CommonAside.vue'

export default {
  // name: 'HomeView',
  components: {
    // CommonAside
  },
  data() {
    return {};
  },
};
</script>

<style lang="less" scoped>
</style>